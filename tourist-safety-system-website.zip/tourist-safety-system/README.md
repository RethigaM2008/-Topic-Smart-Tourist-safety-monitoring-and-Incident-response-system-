# Smart Tourist Safety Monitoring & Incident Response System

A simple responsive frontend website created as an academic project demo.

## Run
Open `index.html` in a browser.

## Deploy on Vercel
1. Create a GitHub repository.
2. Upload `index.html`.
3. In Vercel choose **Import Git Repository**.
4. Select the repository.
5. Deploy. No build command is required for this static website.
